-- =========================================================
-- ComputerFix - skema database (MySQL 5.7+ / MariaDB 10.3+)
-- Import lewat phpMyAdmin: tab Import -> pilih file ini.
-- Aman dijalankan ulang (CREATE TABLE IF NOT EXISTS).
-- =========================================================
CREATE DATABASE IF NOT EXISTS computerfix
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE computerfix;

CREATE TABLE IF NOT EXISTS users (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nama       VARCHAR(100) NOT NULL,
  email      VARCHAR(150) NOT NULL,
  password   VARCHAR(255) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS bookings (
  id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  kode_booking      VARCHAR(20)  NOT NULL UNIQUE,
  nama              VARCHAR(100) NOT NULL,
  no_hp             VARCHAR(20)  NOT NULL,
  catatan           VARCHAR(500) NOT NULL DEFAULT '',
  tanggal           DATE NOT NULL,
  jam               TIME NOT NULL,
  subtotal          DECIMAL(12,2) NOT NULL DEFAULT 0,  -- total sparepart
  biaya_booking     DECIMAL(12,2) NOT NULL DEFAULT 0,
  total             DECIMAL(12,2) NOT NULL DEFAULT 0,  -- yang harus dibayar
  status_pembayaran ENUM('menunggu','lunas') NOT NULL DEFAULT 'menunggu',
  batas_bayar       DATETIME NULL,
  dibayar_pada      DATETIME NULL,
  created_at        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_jadwal (tanggal, jam)                  -- 1 slot = 1 booking
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS booking_items (
  id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  kode_booking   VARCHAR(20)  NOT NULL,
  nama           VARCHAR(100) NOT NULL,   -- nama pelanggan (dipertahankan)
  nama_sparepart VARCHAR(150) NOT NULL,
  kategori       VARCHAR(80)  NOT NULL DEFAULT 'Sparepart',
  harga          DECIMAL(12,2) NOT NULL,
  jumlah         INT NOT NULL,
  KEY idx_kode (kode_booking),
  CONSTRAINT fk_item_booking FOREIGN KEY (kode_booking)
    REFERENCES bookings (kode_booking) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS payments (
  id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  kode_pembayaran VARCHAR(24) NOT NULL UNIQUE,
  kode_booking   VARCHAR(20)  NOT NULL,
  metode         VARCHAR(20)  NOT NULL DEFAULT 'QRIS',
  jumlah         DECIMAL(12,2) NOT NULL,
  status         ENUM('berhasil','gagal') NOT NULL DEFAULT 'berhasil',
  dibayar_pada   DATETIME NOT NULL,
  KEY idx_kode (kode_booking),
  CONSTRAINT fk_pay_booking FOREIGN KEY (kode_booking)
    REFERENCES bookings (kode_booking) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =========================================================
-- JIKA tabel bookings SUDAH ADA dari versi lama, jalankan ini
-- (satu per satu; abaikan error "Duplicate column"):
-- =========================================================
-- ALTER TABLE bookings ADD COLUMN subtotal DECIMAL(12,2) NOT NULL DEFAULT 0 AFTER jam;
-- ALTER TABLE bookings ADD COLUMN biaya_booking DECIMAL(12,2) NOT NULL DEFAULT 0 AFTER subtotal;
-- ALTER TABLE bookings ADD COLUMN status_pembayaran ENUM('menunggu','lunas') NOT NULL DEFAULT 'lunas' AFTER total;
-- ALTER TABLE bookings ADD COLUMN batas_bayar DATETIME NULL;
-- ALTER TABLE bookings ADD COLUMN dibayar_pada DATETIME NULL;
-- UPDATE bookings SET subtotal = total WHERE subtotal = 0;
