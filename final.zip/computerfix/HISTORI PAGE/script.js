const KEY = "computerfix_booking_codes";
const listEl = document.getElementById("historyList");
const stateEl = document.getElementById("stateMessage");
const toast = document.getElementById("toast");
let toastTimer;

function rupiah(v) {
    return new Intl.NumberFormat("id-ID", {
        style: "currency", currency: "IDR", maximumFractionDigits: 0
    }).format(Number(v) || 0);
}

function escapeHTML(v) {
    return String(v).replace(/[&<>"']/g, c => ({
        "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    })[c]);
}

function formatDate(d) {
    return new Date(d + "T12:00:00").toLocaleDateString("id-ID", {
        weekday: "long", day: "numeric", month: "long", year: "numeric"
    });
}

function formatDateTime(s) {
    if (!s) return "-";
    return new Date(s.replace(" ", "T")).toLocaleString("id-ID", {
        day: "numeric", month: "short", year: "numeric",
        hour: "2-digit", minute: "2-digit"
    });
}

function showToast(m) {
    toast.textContent = m;
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("show"), 2600);
}

function getCodes() {
    try {
        const c = JSON.parse(localStorage.getItem(KEY));
        return Array.isArray(c) ? c : [];
    } catch { return []; }
}

function saveCodes(codes) {
    localStorage.setItem(KEY, JSON.stringify(codes));
}

function card(h, extra) {
    const lunas = h.status_pembayaran === "lunas";
    const metode = h.metode || "QRIS";

    const items = h.items.length
        ? h.items.map(i => `
            <div class="hc-item">
                <span>${escapeHTML(i.nama)} <em>× ${Number(i.jumlah)}</em></span>
                <strong>${rupiah(Number(i.harga) * Number(i.jumlah))}</strong>
            </div>`).join("")
        : "<p class='no-items'>Tanpa sparepart.</p>";

    return `
    <article class="history-card ${lunas ? "is-paid" : "is-pending"}">
        ${extra || ""}

        <header class="hc-top">
            <div>
                <span class="hc-label">Kode booking</span>
                <strong class="hcode">${escapeHTML(h.kode_booking)}</strong>
            </div>
            <span class="badge ${lunas ? "paid" : "pending"}">
                ${lunas ? "✓ Lunas" : "● Menunggu pembayaran"}
            </span>
        </header>

        <ol class="hc-steps">
            <li class="done"><span>1</span>Booking dibuat</li>
            <li class="${lunas ? "done" : "active"}"><span>2</span>Pembayaran</li>
            <li class="${lunas ? "done" : ""}"><span>3</span>Terkonfirmasi</li>
        </ol>

        <div class="hc-body">
            <div class="hc-info">
                <div class="hc-tile wide">
                    <small>Jadwal kunjungan</small>
                    <strong>${formatDate(h.tanggal)}</strong>
                    <span>Pukul ${escapeHTML(h.jam)} WIB</span>
                </div>
                <div class="hc-tile">
                    <small>Atas nama</small>
                    <strong>${escapeHTML(h.nama)}</strong>
                </div>
                <div class="hc-tile">
                    <small>Metode bayar</small>
                    <strong>${lunas ? escapeHTML(metode) : "-"}</strong>
                </div>
                <div class="hc-tile">
                    <small>Dibayar pada</small>
                    <strong>${lunas ? formatDateTime(h.dibayar_pada) : "-"}</strong>
                </div>
                <div class="hc-tile">
                    <small>Kode pembayaran</small>
                    <strong>${lunas && h.kode_pembayaran ? escapeHTML(h.kode_pembayaran) : "-"}</strong>
                </div>
            </div>

            <div class="hc-order">
                <h4>Rincian pesanan</h4>
                ${items}
                <div class="hc-item">
                    <span>Biaya booking</span>
                    <strong>${rupiah(h.biaya_booking)}</strong>
                </div>
                <div class="hc-total">
                    <span>Total</span>
                    <strong>${rupiah(h.total)}</strong>
                </div>
            </div>
        </div>

        ${lunas ? "" : `<a class="btn btn-primary pay-link"
            href="../PAYMENT%20PAGE/index.html?kode=${encodeURIComponent(h.kode_booking)}">Lanjut Bayar →</a>`}
    </article>`;
}

const searchForm = document.getElementById("searchForm");
const searchInput = document.getElementById("searchInput");
const searchInfo = document.getElementById("searchInfo");
const resetButton = document.getElementById("resetButton");
const KODE_RE = /^[A-Z0-9-]{3,20}$/;

let allHistory = [];

async function fetchByCodes(codes) {
    const res = await fetch("../backend/histori.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ kode: codes })
    });
    let data;
    try {
        data = await res.json();
    } catch (e) {
        throw new Error("Server tidak mengirim data yang valid (cek file histori.php dan koneksi.php).");
    }
    if (!res.ok || !data.success) throw new Error(data.message || "Gagal");
    return data.histori;
}

function setInfo(text) {
    searchInfo.hidden = !text;
    searchInfo.textContent = text || "";
}

function showList(list, emptyHtml) {
    if (list.length === 0) {
        stateEl.hidden = false;
        stateEl.innerHTML = emptyHtml;
        listEl.innerHTML = "";
        return;
    }
    stateEl.hidden = true;
    listEl.innerHTML = list.map(h => card(h)).join("");
}

const EMPTY_DEFAULT =
    'Belum ada histori. <a href="../BOOKING%20PAGE/index.html">Buat booking →</a>';

async function loadHistory() {
    const codes = getCodes();
    resetButton.hidden = true;
    setInfo("");

    if (codes.length === 0) {
        allHistory = [];
        showList([], EMPTY_DEFAULT);
        return;
    }

    try {
        allHistory = await fetchByCodes(codes);

        // buang kode yang sudah tidak ada di database (mis. kedaluwarsa)
        const ada = new Set(allHistory.map(h => h.kode_booking));
        saveCodes(codes.filter(c => ada.has(c)));

        showList(allHistory, EMPTY_DEFAULT);
    } catch (error) {
        console.error(error);
        stateEl.hidden = false;
        stateEl.textContent = "Histori gagal dimuat: " + error.message;
        listEl.innerHTML = "";
    }
}

const EMPTY_SEARCH = (q) =>
    "Tidak ada booking yang cocok dengan <b>" + escapeHTML(q) + "</b>. " +
    "Kalau ini kode booking lengkap, tekan tombol Cari untuk mencari ke database.";

async function runSearch(submitted) {
    const raw = searchInput.value.trim();
    const q = raw.toUpperCase();

    if (!q) {
        showList(allHistory, EMPTY_DEFAULT);
        resetButton.hidden = true;
        setInfo("");
        return;
    }

    resetButton.hidden = false;

    // kode yang persis sama dengan yang ada di histori browser ini
    const lokal = allHistory.find(h => h.kode_booking.toUpperCase() === q);
    if (lokal) {
        setInfo("Hasil pencarian untuk " + q);
        showList([lokal], "");
        return;
    }

    // saring daftar histori (kode / nama / tanggal / status)
    const kata = raw.toLowerCase();
    const cocok = allHistory.filter(h =>
        h.kode_booking.toLowerCase().includes(kata) ||
        String(h.nama).toLowerCase().includes(kata) ||
        String(h.tanggal).includes(kata) ||
        (kata === "lunas" && h.status_pembayaran === "lunas") ||
        (kata === "menunggu" && h.status_pembayaran === "menunggu")
    );

    // saat mengetik: cukup saring daftar lokal
    if (!submitted) {
        setInfo(cocok.length + " hasil untuk \"" + raw + "\"");
        showList(cocok, EMPTY_SEARCH(raw));
        return;
    }

    // saat menekan Cari: cek dulu ke database
    if (KODE_RE.test(q)) {
        setInfo("Mencari " + q + "...");
        try {
            const hasil = await fetchByCodes([q]);

            if (searchInput.value.trim().toUpperCase() !== q) return;

            if (hasil.length > 0) {
                setInfo("Hasil pencarian untuk " + hasil[0].kode_booking);
                stateEl.hidden = true;
                listEl.innerHTML = card(hasil[0],
                    `<div class="result-note">
                        Booking ini belum ada di histori browser ini.
                        <button type="button" class="save-link" data-kode="${escapeHTML(hasil[0].kode_booking)}">Simpan ke histori</button>
                    </div>`);
                return;
            }
        } catch (error) {
            console.error(error);
            setInfo("");
            showList([], "Pencarian gagal: " + escapeHTML(error.message));
            return;
        }
    }

    // tidak ada di database -> tampilkan hasil saringan lokal (kalau ada)
    if (cocok.length > 0) {
        setInfo(cocok.length + " hasil untuk \"" + raw + "\"");
        showList(cocok, "");
    } else {
        setInfo("");
        showList([], "Kode <b>" + escapeHTML(q) +
            "</b> tidak ditemukan atau sudah kedaluwarsa.");
    }
}

searchForm.addEventListener("submit", event => {
    event.preventDefault();
    runSearch(true);
});

searchInput.addEventListener("input", () => {
    runSearch(false);
});

resetButton.addEventListener("click", () => {
    searchInput.value = "";
    runSearch(false);
    searchInput.focus();
});

listEl.addEventListener("click", event => {
    const btn = event.target.closest(".save-link");
    if (!btn) return;

    const codes = getCodes();
    if (!codes.includes(btn.dataset.kode)) codes.push(btn.dataset.kode);
    saveCodes(codes);
    showToast("Disimpan ke histori.");
    searchInput.value = "";
    loadHistory();
});

loadHistory();
