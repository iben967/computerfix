const params = new URLSearchParams(location.search);
const kode = params.get("kode") || "";

const payLayout = document.getElementById("payLayout");
const stateMessage = document.getElementById("stateMessage");
const successPanel = document.getElementById("successPanel");
const payButton = document.getElementById("payButton");
const cancelButton = document.getElementById("cancelButton");
const toast = document.getElementById("toast");

let toastTimer;
let countdownTimer;
let sisaDetik = 0;
let metode = "qris";

const METODE = {
    qris: {
        label: "QRIS", tombol: "Saya Sudah Bayar",
        cara: [
            "Buka aplikasi e-wallet / mobile banking.",
            "Pilih menu <b>Scan / Bayar QRIS</b>.",
            "Scan kode QR di samping, cek nominal, lalu konfirmasi.",
            "Setelah berhasil, tekan tombol di bawah."
        ]
    },
    dana: { label: "DANA", tombol: "Bayar dengan DANA", cara: [] },
    gopay: { label: "GoPay", tombol: "Bayar dengan GoPay", cara: [] },
    shopeepay: { label: "ShopeePay", tombol: "Bayar dengan ShopeePay", cara: [] }
};

["dana", "gopay", "shopeepay"].forEach(k => {
    METODE[k].cara = [
        "Masukkan nomor HP yang terdaftar di <b>" + METODE[k].label + "</b>.",
        "Cek nominal pembayaran di samping.",
        "Tekan tombol <b>Bayar dengan " + METODE[k].label + "</b>.",
        "Konfirmasi di aplikasi " + METODE[k].label + " (simulasi)."
    ];
});

function pilihMetode(key) {
    metode = key;
    const info = METODE[key];
    const ewallet = key !== "qris";

    document.getElementById("qrisCard").hidden = ewallet;
    document.getElementById("ewalletCard").hidden = !ewallet;
    document.getElementById("howList").innerHTML =
        info.cara.map(c => "<li>" + c + "</li>").join("");
    payButton.textContent = info.tombol;

    if (ewallet) {
        const logo = document.getElementById("ewLogo");
        logo.textContent = info.label;
        logo.className = "pay-logo " + key;
        document.getElementById("ewTitle").textContent = "Bayar dengan " + info.label;
        document.getElementById("ewName").textContent = info.label;
    }
}

function rupiah(value) {
    return new Intl.NumberFormat("id-ID", {
        style: "currency", currency: "IDR", maximumFractionDigits: 0
    }).format(Number(value) || 0);
}

function escapeHTML(value) {
    return String(value).replace(/[&<>"']/g, c => ({
        "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    })[c]);
}

function formatDate(dateString) {
    return new Date(dateString + "T12:00:00").toLocaleDateString("id-ID", {
        weekday: "long", day: "numeric", month: "long", year: "numeric"
    });
}

function showToast(message) {
    toast.textContent = message;
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("show"), 2800);
}

function showState(message, withLink) {
    payLayout.hidden = true;
    stateMessage.hidden = false;
    stateMessage.innerHTML = escapeHTML(message) +
        (withLink ? ' <a href="../BOOKING%20PAGE/index.html">Booking ulang →</a>' : "");
}

/* ---------- QR simulasi (bukan QR sungguhan) ---------- */
function seededRandom(text) {
    let h = 2166136261;
    for (let i = 0; i < text.length; i++) {
        h ^= text.charCodeAt(i);
        h = Math.imul(h, 16777619);
    }
    return function () {
        h += 0x6D2B79F5;
        let t = Math.imul(h ^ (h >>> 15), 1 | h);
        t ^= t + Math.imul(t ^ (t >>> 7), 61 | t);
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
}

function drawFakeQR(seed) {
    const n = 29;
    const rand = seededRandom(seed);
    const grid = Array.from({ length: n }, () => Array(n).fill(0));
    const reserved = Array.from({ length: n }, () => Array(n).fill(false));

    function finder(r, c) {
        for (let y = -1; y <= 7; y++) {
            for (let x = -1; x <= 7; x++) {
                const yy = r + y, xx = c + x;
                if (yy < 0 || xx < 0 || yy >= n || xx >= n) continue;
                reserved[yy][xx] = true;
                const edge = y === 0 || y === 6 || x === 0 || x === 6;
                const core = y >= 2 && y <= 4 && x >= 2 && x <= 4;
                grid[yy][xx] = (y >= 0 && y <= 6 && x >= 0 && x <= 6 && (edge || core)) ? 1 : 0;
            }
        }
    }
    finder(0, 0); finder(0, n - 7); finder(n - 7, 0);

    for (let y = 0; y < n; y++) {
        for (let x = 0; x < n; x++) {
            if (!reserved[y][x]) grid[y][x] = rand() < 0.5 ? 1 : 0;
        }
    }

    const cell = 8;
    let rects = "";
    for (let y = 0; y < n; y++) {
        for (let x = 0; x < n; x++) {
            if (grid[y][x]) rects += `<rect x="${x * cell}" y="${y * cell}" width="${cell}" height="${cell}"/>`;
        }
    }
    const size = n * cell;
    return `<svg viewBox="0 0 ${size} ${size}" xmlns="http://www.w3.org/2000/svg" shape-rendering="crispEdges"><rect width="${size}" height="${size}" fill="#fff"/><g fill="#111">${rects}</g></svg>`;
}

/* ---------- Hitung mundur ---------- */
function renderCountdown() {
    const m = String(Math.floor(sisaDetik / 60)).padStart(2, "0");
    const s = String(sisaDetik % 60).padStart(2, "0");
    document.getElementById("countdown").textContent = m + ":" + s;
    document.getElementById("countdown2").textContent = m + ":" + s;
}

function startCountdown() {
    renderCountdown();
    clearInterval(countdownTimer);
    countdownTimer = setInterval(() => {
        sisaDetik -= 1;
        if (sisaDetik <= 0) {
            clearInterval(countdownTimer);
            showState("Waktu pembayaran habis. Slot jadwal dilepas kembali.", true);
            return;
        }
        renderCountdown();
    }, 1000);
}

/* ---------- Muat tagihan ---------- */
async function loadPayment() {
    if (!/^[A-Za-z0-9-]{3,20}$/.test(kode)) {
        showState("Kode booking tidak valid.", true);
        return;
    }

    try {
        const response = await fetch(
            "../backend/detail_pembayaran.php?kode=" + encodeURIComponent(kode)
        );
        const data = await response.json();

        if (!response.ok || !data.success) {
            showState(data.message || "Tagihan tidak ditemukan.", true);
            return;
        }

        const b = data.booking;

        if (b.status_pembayaran === "lunas") {
            showSuccess(b.nama);
            return;
        }

        document.getElementById("merchantName").textContent = data.merchant;
        document.getElementById("nmid").textContent = data.nmid;
        document.getElementById("amount").textContent = rupiah(b.total);
        document.getElementById("amount2").textContent = rupiah(b.total);
        document.getElementById("qrBox").innerHTML = drawFakeQR(kode + "|" + b.total);

        document.getElementById("dKode").textContent = b.kode_booking;
        document.getElementById("dNama").textContent = b.nama;
        document.getElementById("dJadwal").textContent =
            formatDate(b.tanggal) + ", " + b.jam;
        document.getElementById("dBiaya").textContent = rupiah(b.biaya_booking);
        document.getElementById("dTotal").textContent = rupiah(b.total);

        document.getElementById("dItems").innerHTML = data.items.length
            ? data.items.map(i => `
                <div class="summary-item">
                    <span>${escapeHTML(i.nama)} × ${Number(i.jumlah)}</span>
                    <strong>${rupiah(Number(i.harga) * Number(i.jumlah))}</strong>
                </div>`).join("")
            : "<p class='no-items'>Tanpa sparepart.</p>";

        payLayout.hidden = false;
        pilihMetode(metode);
        sisaDetik = Number(data.sisa_detik) || 0;
        startCountdown();
    } catch (error) {
        console.error(error);
        showState("Gagal terhubung ke server. Buka website lewat localhost (XAMPP).", false);
    }
}

function showSuccess(nama, namaMetode) {
    clearInterval(countdownTimer);
    payLayout.hidden = true;
    stateMessage.hidden = true;
    document.querySelector(".page-heading").hidden = true;
    successPanel.hidden = false;
    document.getElementById("successCode").textContent = kode;
    if (namaMetode) {
        document.getElementById("successMethod").textContent = "Dibayar via " + namaMetode;
    }
    if (nama) {
        document.getElementById("successText").textContent =
            "Terima kasih, " + nama + ". Booking kamu sudah terkonfirmasi.";
    }

    sessionStorage.setItem("computerfix_flash", "Pembayaran berhasil! Booking " + kode + " sudah terkonfirmasi.");
    setTimeout(() => {
        location.href = "../LANDING%20PAGE/index.html";
    }, 3000);
}

/* ---------- Aksi ---------- */
document.getElementById("methodList").addEventListener("change", event => {
    if (event.target.name === "metode") pilihMetode(event.target.value);
});

payButton.addEventListener("click", async () => {
    const noEwallet = document.getElementById("ewPhone").value.trim();

    if (metode !== "qris" &&
        !/^(\+62|62|0)8[0-9]{8,12}$/.test(noEwallet.replace(/[\s-]/g, ""))) {
        showToast("Isi nomor " + METODE[metode].label + " yang valid.");
        return;
    }

    payButton.disabled = true;
    payButton.textContent = "Memproses pembayaran...";

    try {
        const response = await fetch("../backend/proses_pembayaran.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ kode, metode, no_ewallet: noEwallet })
        });
        const data = await response.json();

        if (!response.ok || !data.success) {
            if (response.status === 410) {
                showState(data.message, true);
            } else {
                showToast(data.message || "Pembayaran gagal diproses.");
            }
            return;
        }

        showSuccess(document.getElementById("dNama").textContent, data.metode);
    } catch (error) {
        console.error(error);
        showToast("Gagal terhubung ke server.");
    } finally {
        payButton.disabled = false;
        payButton.textContent = METODE[metode].tombol;
    }
});

cancelButton.addEventListener("click", async () => {
    if (!confirm("Batalkan booking ini? Slot jadwal akan dilepas.")) return;

    try {
        const response = await fetch("../backend/batal_booking.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ kode })
        });
        const data = await response.json();

        if (!response.ok || !data.success) {
            showToast(data.message || "Gagal membatalkan booking.");
            return;
        }

        try {
            const codes = JSON.parse(localStorage.getItem("computerfix_booking_codes")) || [];
            localStorage.setItem("computerfix_booking_codes",
                JSON.stringify(codes.filter(c => c !== kode)));
        } catch (e) { /* abaikan */ }

        clearInterval(countdownTimer);
        showState("Booking dibatalkan.", true);
    } catch (error) {
        console.error(error);
        showToast("Gagal terhubung ke server.");
    }
});

loadPayment();
