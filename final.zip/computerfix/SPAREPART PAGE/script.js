const products = [
    // ===== PROSESOR =====
    {id:"cpu-01", name:"Intel Core i3-10400", category:"Prosesor", price:1450000, stock:9, desc:"Prosesor Intel Core i3 generasi ke-10 untuk PC harian", image:"image/intel-i3-10400.png"},
    {id:"cpu-02", name:"Intel Core i5-10400", category:"Prosesor", price:2250000, stock:8, desc:"Prosesor Intel Core i5 generasi ke-10, 6 core", image:"image/intel-i5-10400.png"},
    {id:"cpu-03", name:"Intel Core i7-13700K", category:"Prosesor", price:6250000, stock:4, desc:"Prosesor Intel Core i7 unlocked untuk gaming dan kerja berat", image:"image/intel-i7-13700k.png"},
    {id:"cpu-04", name:"Intel Core i9-13900K", category:"Prosesor", price:8950000, stock:3, desc:"Prosesor Intel Core i9 unlocked performa tertinggi", image:"image/intel-i9-13900k.png"},
    {id:"cpu-05", name:"AMD Ryzen 3", category:"Prosesor", price:1350000, stock:10, desc:"Prosesor AMD Ryzen 3 dengan Radeon Graphics", image:"image/ryzen-3.png"},
    {id:"cpu-06", name:"AMD Ryzen 5", category:"Prosesor", price:2650000, stock:7, desc:"Prosesor AMD Ryzen 5 untuk gaming dan multitasking", image:"image/ryzen-5.png"},
    {id:"cpu-07", name:"AMD Ryzen 7", category:"Prosesor", price:4250000, stock:5, desc:"Prosesor AMD Ryzen 7 untuk kreator dan gamer", image:"image/ryzen-7.png"},
    {id:"cpu-08", name:"AMD Ryzen 9", category:"Prosesor", price:7950000, stock:3, desc:"Prosesor AMD Ryzen 9 kelas enthusiast", image:"image/ryzen-9.png"},

    // ===== KARTU GRAFIS =====
    {id:"gpu-01", name:"Gigabyte GeForce RTX 3050", category:"Grafis", price:3250000, stock:5, desc:"Kartu grafis Gigabyte RTX 3050 untuk gaming Full HD", image:"image/rtx3050.png"},
    {id:"gpu-02", name:"ASUS Dual GeForce RTX 4050", category:"Grafis", price:4850000, stock:4, desc:"Kartu grafis ASUS Dual dengan pendingin dua kipas", image:"image/rtx4050.png"},
    {id:"gpu-03", name:"ASUS Dual GeForce RTX 2060 OC 12GB", category:"Grafis", price:3950000, stock:3, desc:"Kartu grafis ASUS Dual OC Edition dengan VRAM 12GB", image:"image/s-l500.jpg"},

    // ===== RAM =====
    {id:"ram-01", name:"RAM DDR4 4GB", category:"Memori", price:150000, stock:18, desc:"Memori untuk PC kompatibel, cocok untuk upgrade ringan", image:"image/ram4gb.png"},
    {id:"ram-02", name:"RAM DDR4 8GB", category:"Memori", price:280000, stock:15, desc:"Memori untuk PC kompatibel", image:"image/ram8gb.png"},
    {id:"ram-03", name:"RAM DDR4 16GB", category:"Memori", price:490000, stock:10, desc:"Kapasitas memori lebih besar"},

    // ===== PENYIMPANAN =====
    {id:"ssd-01", name:"SSD NVMe 256GB", category:"Penyimpanan", price:350000, stock:12, desc:"Penyimpanan cepat untuk sistem", image:"image/ssd256.png"},
    {id:"ssd-02", name:"SSD NVMe 512GB", category:"Penyimpanan", price:620000, stock:7, desc:"Penyimpanan cepat berkapasitas besar", image:"image/ssd512.png"},
    {id:"hdd-01", name:"HDD 1TB", category:"Penyimpanan", price:650000, stock:6, desc:"Penyimpanan data berkapasitas besar"},

    // ===== SPAREPART LAPTOP =====
    {id:"bat-01", name:"Baterai Laptop ASUS", category:"Laptop", price:450000, stock:4, desc:"Pastikan model cocok dengan laptop", image:"image/batteraiasustuf.jpg"},

    // ===== PERIFERAL =====
    {id:"key-01", name:"Keyboard Mechanical Compact", category:"Periferal", price:325000, stock:14, desc:"Keyboard mechanical ukuran ringkas dengan keycap dua warna", image:"image/keyboard.png"},
    {id:"key-02", name:"Keyboard Mechanical Retro", category:"Periferal", price:375000, stock:9, desc:"Keyboard mechanical bergaya retro", image:"image/images.jpg"},
    {id:"mouse-01", name:"Mouse Gaming Vortex ONI R1", category:"Periferal", price:285000, stock:20, desc:"Mouse gaming wireless dengan tiga mode koneksi", image:"image/mouseonir1.jpg"},
    {id:"mon-01", name:"Monitor Samsung QLED Gaming Curved", category:"Periferal", price:5450000, stock:3, desc:"Monitor gaming layar lengkung QLED", image:"image/gamingmonitor.png"},
    {id:"mon-02", name:"Monitor Curved Gaming", category:"Periferal", price:1850000, stock:5, desc:"Monitor layar lengkung untuk PC desktop", image:"image/monitoramoled.png"}
];

const productGrid = document.getElementById("productGrid");
const searchInput = document.getElementById("searchInput");
const sortSelect = document.getElementById("sortSelect");
const resultCount = document.getElementById("resultCount");
const emptyResult = document.getElementById("emptyResult");
const toast = document.getElementById("toast");
let activeCategory = "Semua";
let toastTimer;

function rupiah(value) {
    return new Intl.NumberFormat("id-ID", {
        style:"currency", currency:"IDR", maximumFractionDigits:0
    }).format(value);
}

function getCart() {
    try {
        return JSON.parse(sessionStorage.getItem("computerfix_cart")) || [];
    } catch (error) {
        return [];
    }
}

function updateCartCount() {
    const total = getCart().reduce((sum, item) => sum + Number(item.jumlah || 0), 0);
    document.getElementById("cartCount").textContent = total;
}

function showToast(message) {
    toast.textContent = message;
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("show"), 2400);
}

function renderProducts() {
    let list = products.filter(product => {
        const matchesCategory = activeCategory === "Semua" ||
            product.category === activeCategory;
        const keyword = searchInput.value.toLowerCase().trim();
        const matchesSearch = (product.name + " " + product.category + " " + product.desc)
            .toLowerCase().includes(keyword);
        return matchesCategory && matchesSearch;
    });

    if (sortSelect.value === "low") list.sort((a,b) => a.price - b.price);
    if (sortSelect.value === "high") list.sort((a,b) => b.price - a.price);
    if (sortSelect.value === "name") list.sort((a,b) => a.name.localeCompare(b.name));

    resultCount.textContent = `Menampilkan ${list.length} produk`;
    emptyResult.hidden = list.length !== 0;

    productGrid.innerHTML = list.map(product => `
        <article class="product-card">
            <div class="product-image ${product.image ? "has-image" : ""}">
                ${product.image
                    ? `<img src="${product.image}" alt="${product.name}" loading="lazy">`
                    : `<span>Gambar produk</span>`}
            </div>
            <div class="product-info">
                <span class="category-label">${product.category}</span>
                <h3>${product.name}</h3>
                <p class="description">${product.desc}</p>
                <p class="price">${rupiah(product.price)}</p>
                <p class="stock ${product.stock <= 4 ? "low-stock" : ""}">
                    Stok demo: ${product.stock} unit
                </p>
                <button class="add-button" data-id="${product.id}"
                    ${product.stock < 1 ? "disabled" : ""}>
                    ${product.stock < 1 ? "Stok Habis" : "＋ Tambah ke Keranjang"}
                </button>
            </div>
        </article>
    `).join("");
}

productGrid.addEventListener("click", event => {
    const button = event.target.closest(".add-button");
    if (!button) return;

    const product = products.find(item => item.id === button.dataset.id);
    if (!product) return;

    const cart = getCart();
    const existing = cart.find(item => item.id === product.id);
    const currentQuantity = existing ? Number(existing.jumlah) : 0;

    if (currentQuantity >= product.stock) {
        showToast("Jumlah di keranjang sudah mencapai stok demo.");
        return;
    }

    if (existing) {
        existing.jumlah += 1;
    } else {
        cart.push({
            id: product.id,
            nama: product.name,
            kategori: product.category,
            gambar: product.image || "",
            harga: product.price,
            jumlah: 1,
            stok: product.stock
        });
    }

    sessionStorage.setItem("computerfix_cart", JSON.stringify(cart));
    updateCartCount();
    showToast(product.name + " ditambahkan ke keranjang.");
});

document.getElementById("categoryFilters").addEventListener("click", event => {
    const button = event.target.closest("button[data-category]");
    if (!button) return;
    activeCategory = button.dataset.category;
    document.querySelectorAll(".filter").forEach(item => item.classList.remove("active"));
    button.classList.add("active");
    renderProducts();
});

searchInput.addEventListener("input", renderProducts);
sortSelect.addEventListener("change", renderProducts);

renderProducts();
updateCartCount();
