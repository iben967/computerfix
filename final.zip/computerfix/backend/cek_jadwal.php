<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/koneksi.php';
require_once __DIR__ . '/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'message' => 'Metode request tidak diizinkan.'
    ]);
    exit;
}

$tanggal = $_GET['tanggal'] ?? '';
$date = DateTime::createFromFormat('!Y-m-d', $tanggal);

if (!$date || $date->format('Y-m-d') !== $tanggal) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => 'Tanggal tidak valid.'
    ]);
    exit;
}

bersihkanKadaluarsa($conn);

$stmt = mysqli_prepare(
    $conn,
    'SELECT jam FROM bookings WHERE tanggal = ?'
);

mysqli_stmt_bind_param($stmt, 's', $tanggal);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);
$terisi = [];

while ($row = mysqli_fetch_assoc($result)) {
    $terisi[] = substr($row['jam'], 0, 5);
}

mysqli_stmt_close($stmt);

echo json_encode([
    'success' => true,
    'tanggal' => $tanggal,
    'terisi' => $terisi
]);