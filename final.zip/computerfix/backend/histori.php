<?php
// POST {kode: [..]} -> riwayat booking & pembayaran untuk kode-kode tertentu.
require_once __DIR__ . '/koneksi.php';
require_once __DIR__ . '/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonOut(405, ['success' => false, 'message' => 'Metode tidak diizinkan.']);
}

$input = json_decode(file_get_contents('php://input'), true);
$daftar = is_array($input['kode'] ?? null) ? $input['kode'] : [];
$daftar = array_values(array_unique(array_filter(
    array_map('strval', $daftar),
    'kodeValid'
)));
$daftar = array_slice($daftar, 0, 50);

if (count($daftar) === 0) {
    jsonOut(200, ['success' => true, 'histori' => []]);
}

try {
    // Hapus booking belum bayar yang sudah lewat batas waktu
    bersihkanKadaluarsa($conn);

    // 1) Data booking
    $ph = implode(',', array_fill(0, count($daftar), '?'));
    $stmt = mysqli_prepare(
        $conn,
        "SELECT kode_booking, nama, tanggal,
                TIME_FORMAT(jam, '%H:%i') AS jam,
                subtotal, biaya_booking, total,
                status_pembayaran, batas_bayar, dibayar_pada
         FROM bookings
         WHERE kode_booking IN ($ph)
         ORDER BY tanggal DESC, jam DESC"
    );
    if (!$stmt) {
        throw new Exception('Query booking: ' . mysqli_error($conn));
    }
    mysqli_stmt_bind_param($stmt, str_repeat('s', count($daftar)), ...$daftar);
    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception('Query booking: ' . mysqli_stmt_error($stmt));
    }
    $res = mysqli_stmt_get_result($stmt);

    $histori = [];
    while ($row = mysqli_fetch_assoc($res)) {
        $row['items'] = [];
        $row['kode_pembayaran'] = null;
        $row['metode'] = null;
        $histori[$row['kode_booking']] = $row;
    }
    mysqli_stmt_close($stmt);

    if ($histori) {
        $kodeList = array_keys($histori);
        $ph = implode(',', array_fill(0, count($kodeList), '?'));
        $tipe = str_repeat('s', count($kodeList));

        // 2) Item sparepart (kalau gagal, histori tetap tampil)
        $stmt = mysqli_prepare(
            $conn,
            "SELECT kode_booking, nama_sparepart AS nama, harga, jumlah
             FROM booking_items WHERE kode_booking IN ($ph)"
        );
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, $tipe, ...$kodeList);
            if (mysqli_stmt_execute($stmt)) {
                $res = mysqli_stmt_get_result($stmt);
                while ($row = mysqli_fetch_assoc($res)) {
                    $histori[$row['kode_booking']]['items'][] = [
                        'nama'   => $row['nama'],
                        'harga'  => $row['harga'],
                        'jumlah' => $row['jumlah']
                    ];
                }
            }
            mysqli_stmt_close($stmt);
        }

        // 3) Data pembayaran (kalau gagal, histori tetap tampil)
        $stmt = mysqli_prepare(
            $conn,
            "SELECT kode_booking, kode_pembayaran, metode
             FROM payments WHERE kode_booking IN ($ph)"
        );
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, $tipe, ...$kodeList);
            if (mysqli_stmt_execute($stmt)) {
                $res = mysqli_stmt_get_result($stmt);
                while ($row = mysqli_fetch_assoc($res)) {
                    $histori[$row['kode_booking']]['kode_pembayaran'] = $row['kode_pembayaran'];
                    $histori[$row['kode_booking']]['metode'] = $row['metode'];
                }
            }
            mysqli_stmt_close($stmt);
        }
    }

    jsonOut(200, ['success' => true, 'histori' => array_values($histori)]);

} catch (Throwable $e) {
    error_log('ComputerFix histori error: ' . $e->getMessage());
    jsonOut(500, ['success' => false, 'message' => $e->getMessage()]);
}
