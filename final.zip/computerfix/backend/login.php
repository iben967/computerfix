<?php

include "koneksi.php";

$nama = $_POST['nama'];
$email = $_POST['email'];
$password = $_POST['password'];

$sql = "INSERT INTO users (nama, email, password)
        VALUES ('$nama', '$email', '$password')";

if (mysqli_query($conn, $sql)) {

    echo "Data berhasil masuk ke database!";

} else {

    echo "Data gagal masuk: " . mysqli_error($conn);

}

?>