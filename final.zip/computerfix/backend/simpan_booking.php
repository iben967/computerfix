<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/koneksi.php';
require_once __DIR__ . '/config.php';

function responseJson($status, $data)
{
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    responseJson(405, [
        'success' => false,
        'message' => 'Metode request tidak diizinkan.'
    ]);
}

$input = json_decode(file_get_contents('php://input'), true);

if (!is_array($input)) {
    responseJson(400, [
        'success' => false,
        'message' => 'Data booking tidak terbaca.'
    ]);
}

$nama = trim((string)($input['nama'] ?? ''));
$noHp = trim((string)($input['no_hp'] ?? ''));
$catatan = trim((string)($input['catatan'] ?? ''));
$tanggal = trim((string)($input['tanggal'] ?? ''));
$jam = trim((string)($input['jam'] ?? ''));
$barang = $input['barang'] ?? [];

if ($nama === '' || mb_strlen($nama) > 100) {
    responseJson(422, [
        'success' => false,
        'message' => 'Nama wajib diisi, maksimal 100 karakter.'
    ]);
}

if (!preg_match('/^[0-9+\-\s()]{8,20}$/', $noHp)) {
    responseJson(422, [
        'success' => false,
        'message' => 'Nomor HP tidak valid.'
    ]);
}

if (mb_strlen($catatan) > 500) {
    responseJson(422, [
        'success' => false,
        'message' => 'Catatan maksimal 500 karakter.'
    ]);
}

$date = DateTime::createFromFormat('!Y-m-d', $tanggal);
$today = new DateTime('today');

if (
    !$date ||
    $date->format('Y-m-d') !== $tanggal ||
    $date < $today
) {
    responseJson(422, [
        'success' => false,
        'message' => 'Tanggal booking tidak valid atau sudah lewat.'
    ]);
}

if ((int)$date->format('N') > 5) {
    responseJson(422, [
        'success' => false,
        'message' => 'Booking hanya tersedia Senin sampai Jumat.'
    ]);
}

if (!preg_match('/^(?:0[8-9]|1[0-9]|20):00$/', $jam)) {
    responseJson(422, [
        'success' => false,
        'message' => 'Jam booking harus pukul 08:00 sampai 20:00.'
    ]);
}

if (!is_array($barang)) {
    responseJson(422, [
        'success' => false,
        'message' => 'Data barang tidak valid.'
    ]);
}

$subtotal = 0;
$items = [];

foreach ($barang as $item) {
    if (!is_array($item)) {
        responseJson(422, [
            'success' => false,
            'message' => 'Data barang tidak valid.'
        ]);
    }

    $namaBarang = trim((string)($item['nama'] ?? ''));
    $kategori = trim((string)($item['kategori'] ?? 'Sparepart'));
    $harga = $item['harga'] ?? null;
    $jumlah = filter_var(
        $item['jumlah'] ?? null,
        FILTER_VALIDATE_INT
    );

    if (
        $namaBarang === '' ||
        mb_strlen($namaBarang) > 150 ||
        !is_numeric($harga) ||
        (float)$harga < 0 ||
        $jumlah === false ||
        $jumlah < 1 ||
        $jumlah > 99
    ) {
        responseJson(422, [
            'success' => false,
            'message' => 'Nama, harga, atau jumlah barang tidak valid.'
        ]);
    }

    $harga = (float)$harga;
    $kategori = mb_substr($kategori, 0, 80);

    $items[] = [
        'nama' => $namaBarang,
        'kategori' => $kategori,
        'harga' => $harga,
        'jumlah' => $jumlah
    ];

    $subtotal += $harga * $jumlah;
}

bersihkanKadaluarsa($conn);

$biaya = (float)BIAYA_BOOKING;
$total = $subtotal + $biaya;
$gratis = $total <= 0;
$status = $gratis ? 'lunas' : 'menunggu';
$batasBayar = date('Y-m-d H:i:s', time() + MENIT_BAYAR * 60);

try {
    mysqli_begin_transaction($conn);

    $kodeBooking = 'CF-' . date('ymd') .
        strtoupper(bin2hex(random_bytes(3)));

    $jamDatabase = $jam . ':00';

    // Simpan data booking
    $stmt = mysqli_prepare(
        $conn,
        'INSERT INTO bookings
        (kode_booking, nama, no_hp, catatan, tanggal, jam,
         subtotal, biaya_booking, total, status_pembayaran, batas_bayar)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
    );

    if (!$stmt) {
        throw new Exception('Gagal menyiapkan booking.');
    }

    mysqli_stmt_bind_param(
        $stmt,
        'ssssssdddss',
        $kodeBooking,
        $nama,
        $noHp,
        $catatan,
        $tanggal,
        $jamDatabase,
        $subtotal,
        $biaya,
        $total,
        $status,
        $batasBayar
    );

    if (!mysqli_stmt_execute($stmt)) {
        $errorCode = mysqli_stmt_errno($stmt);
        mysqli_stmt_close($stmt);

        if ($errorCode === 1062) {
            mysqli_rollback($conn);
            responseJson(409, [
                'success' => false,
                'message' => 'Jadwal sudah dipesan. Pilih jam lain.'
            ]);
        }

        throw new Exception('Gagal menyimpan booking.');
    }

    mysqli_stmt_close($stmt);

    // Simpan sparepart (boleh kosong), terhubung lewat kode_booking
    if (count($items) > 0) {
        $itemStmt = mysqli_prepare(
            $conn,
            'INSERT INTO booking_items
            (kode_booking, nama, nama_sparepart, kategori, harga, jumlah)
            VALUES (?, ?, ?, ?, ?, ?)'
        );

        if (!$itemStmt) {
            throw new Exception('Gagal menyiapkan detail barang.');
        }

        foreach ($items as $item) {
            mysqli_stmt_bind_param(
                $itemStmt,
                'ssssdi',
                $kodeBooking,
                $nama,
                $item['nama'],
                $item['kategori'],
                $item['harga'],
                $item['jumlah']
            );

            if (!mysqli_stmt_execute($itemStmt)) {
                mysqli_stmt_close($itemStmt);
                throw new Exception('Gagal menyimpan detail barang.');
            }
        }

        mysqli_stmt_close($itemStmt);
    }

    mysqli_commit($conn);

    responseJson(200, [
        'success' => true,
        'message' => 'Booking berhasil disimpan.',
        'kode_booking' => $kodeBooking,
        'tanggal' => $tanggal,
        'jam' => $jam,
        'total' => $total,
        'perlu_bayar' => !$gratis
    ]);

} catch (Throwable $e) {
    mysqli_rollback($conn);

    if ((int)$e->getCode() === 1062) {
        responseJson(409, [
            'success' => false,
            'message' => 'Jadwal sudah dipesan. Pilih jam lain.'
        ]);
    }

    error_log('ComputerFix booking error: ' . $e->getMessage());

    responseJson(500, [
        'success' => false,
        'message' => 'Gagal menyimpan booking. Periksa database dan koneksi.'
    ]);
}