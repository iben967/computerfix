<?php
// POST {kode} -> batalkan booking yang BELUM dibayar (slot jadwal dibuka lagi)
require_once __DIR__ . '/koneksi.php';
require_once __DIR__ . '/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonOut(405, ['success' => false, 'message' => 'Metode tidak diizinkan.']);
}

$input = json_decode(file_get_contents('php://input'), true);
$kode  = trim((string)($input['kode'] ?? ''));

if (!kodeValid($kode)) {
    jsonOut(400, ['success' => false, 'message' => 'Kode booking tidak valid.']);
}

$stmt = mysqli_prepare(
    $conn,
    "DELETE FROM bookings
     WHERE kode_booking = ? AND status_pembayaran = 'menunggu'"
);
mysqli_stmt_bind_param($stmt, 's', $kode);
mysqli_stmt_execute($stmt);
$dihapus = mysqli_stmt_affected_rows($stmt);
mysqli_stmt_close($stmt);

jsonOut(200, [
    'success' => true,
    'message' => $dihapus > 0
        ? 'Booking dibatalkan.'
        : 'Tidak ada booking yang perlu dibatalkan.'
]);
