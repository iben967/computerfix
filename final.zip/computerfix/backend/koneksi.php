<?php

$host = "localhost";
$user = "root";
$password = "";
$database = "computerfix";

// Biar error database tidak jadi halaman fatal error
mysqli_report(MYSQLI_REPORT_OFF);

$conn = mysqli_connect($host, $user, $password);

if (!$conn) {
    http_response_code(500);
    die("Koneksi database gagal. Pastikan MySQL di XAMPP sudah menyala.");
}

mysqli_set_charset($conn, "utf8mb4");

// ---------- Siapkan database & tabel otomatis ----------
mysqli_query($conn, "CREATE DATABASE IF NOT EXISTS `$database`
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
mysqli_select_db($conn, $database);

mysqli_query($conn, "CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL,
  password VARCHAR(255) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

mysqli_query($conn, "CREATE TABLE IF NOT EXISTS bookings (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  kode_booking VARCHAR(20) NOT NULL UNIQUE,
  nama VARCHAR(100) NOT NULL,
  no_hp VARCHAR(20) NOT NULL,
  catatan VARCHAR(500) NOT NULL DEFAULT '',
  tanggal DATE NOT NULL,
  jam TIME NOT NULL,
  subtotal DECIMAL(12,2) NOT NULL DEFAULT 0,
  biaya_booking DECIMAL(12,2) NOT NULL DEFAULT 0,
  total DECIMAL(12,2) NOT NULL DEFAULT 0,
  status_pembayaran ENUM('menunggu','lunas') NOT NULL DEFAULT 'menunggu',
  batas_bayar DATETIME NULL,
  dibayar_pada DATETIME NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_jadwal (tanggal, jam)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// Kalau tabel bookings sudah ada dari versi lama: tambah kolom yang kurang
$kolomBaru = array(
    'subtotal'          => "DECIMAL(12,2) NOT NULL DEFAULT 0",
    'biaya_booking'     => "DECIMAL(12,2) NOT NULL DEFAULT 0",
    'status_pembayaran' => "ENUM('menunggu','lunas') NOT NULL DEFAULT 'menunggu'",
    'batas_bayar'       => "DATETIME NULL",
    'dibayar_pada'      => "DATETIME NULL",
    'created_at'        => "TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP"
);

foreach ($kolomBaru as $nama => $definisi) {
    $cek = mysqli_query($conn, "SHOW COLUMNS FROM bookings LIKE '$nama'");
    if ($cek && mysqli_num_rows($cek) === 0) {
        mysqli_query($conn, "ALTER TABLE bookings ADD COLUMN $nama $definisi");
        if ($nama === 'status_pembayaran') {
            // booking lama dianggap sudah lunas
            mysqli_query($conn, "UPDATE bookings SET status_pembayaran = 'lunas'");
        }
        if ($nama === 'subtotal') {
            mysqli_query($conn, "UPDATE bookings SET subtotal = total");
        }
    }
}

mysqli_query($conn, "CREATE TABLE IF NOT EXISTS booking_items (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  kode_booking VARCHAR(20) NOT NULL,
  nama VARCHAR(100) NOT NULL,
  nama_sparepart VARCHAR(150) NOT NULL,
  kategori VARCHAR(80) NOT NULL DEFAULT 'Sparepart',
  harga DECIMAL(12,2) NOT NULL,
  jumlah INT NOT NULL,
  KEY idx_kode (kode_booking),
  CONSTRAINT fk_item_booking FOREIGN KEY (kode_booking)
    REFERENCES bookings (kode_booking) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

mysqli_query($conn, "CREATE TABLE IF NOT EXISTS payments (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  kode_pembayaran VARCHAR(24) NOT NULL UNIQUE,
  kode_booking VARCHAR(20) NOT NULL,
  metode VARCHAR(20) NOT NULL DEFAULT 'QRIS',
  jumlah DECIMAL(12,2) NOT NULL,
  status ENUM('berhasil','gagal') NOT NULL DEFAULT 'berhasil',
  dibayar_pada DATETIME NOT NULL,
  KEY idx_kode (kode_booking),
  CONSTRAINT fk_pay_booking FOREIGN KEY (kode_booking)
    REFERENCES bookings (kode_booking) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

?>
