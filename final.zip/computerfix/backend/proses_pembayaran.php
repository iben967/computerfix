<?php
// POST {kode} -> tandai booking LUNAS dan catat transaksi di tabel payments.
// CATATAN: ini simulasi QRIS. Untuk QRIS asli, status "lunas" harus diubah
// oleh webhook/callback payment gateway (Midtrans, Xendit, dll), bukan
// oleh tombol di browser.
require_once __DIR__ . '/koneksi.php';
require_once __DIR__ . '/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonOut(405, ['success' => false, 'message' => 'Metode tidak diizinkan.']);
}

$input = json_decode(file_get_contents('php://input'), true);
$kode  = trim((string)($input['kode'] ?? ''));
$metodeKey = strtolower(trim((string)($input['metode'] ?? 'qris')));
$noEwallet = preg_replace('/[\s\-]/', '', (string)($input['no_ewallet'] ?? ''));

$daftarMetode = [
    'qris'      => 'QRIS',
    'dana'      => 'DANA',
    'gopay'     => 'GoPay',
    'shopeepay' => 'ShopeePay'
];

if (!isset($daftarMetode[$metodeKey])) {
    jsonOut(422, ['success' => false, 'message' => 'Metode pembayaran tidak valid.']);
}
$metode = $daftarMetode[$metodeKey];

if ($metodeKey !== 'qris' && !preg_match('/^(\+62|62|0)8[0-9]{8,12}$/', $noEwallet)) {
    jsonOut(422, ['success' => false, 'message' => 'Nomor ' . $metode . ' tidak valid.']);
}

if (!kodeValid($kode)) {
    jsonOut(400, ['success' => false, 'message' => 'Kode booking tidak valid.']);
}

bersihkanKadaluarsa($conn);

try {
    mysqli_begin_transaction($conn);

    $stmt = mysqli_prepare(
        $conn,
        'SELECT total, status_pembayaran FROM bookings
         WHERE kode_booking = ? FOR UPDATE'
    );
    mysqli_stmt_bind_param($stmt, 's', $kode);
    mysqli_stmt_execute($stmt);
    $booking = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    mysqli_stmt_close($stmt);

    if (!$booking) {
        mysqli_rollback($conn);
        jsonOut(410, [
            'success' => false,
            'message' => 'Waktu pembayaran habis. Silakan booking ulang.'
        ]);
    }

    if ($booking['status_pembayaran'] === 'lunas') {
        mysqli_commit($conn);
        jsonOut(200, [
            'success' => true,
            'message' => 'Pembayaran sudah tercatat sebelumnya.'
        ]);
    }

    $sekarang = date('Y-m-d H:i:s');
    $total    = (float)$booking['total'];
    $kodeBayar = 'PAY-' . date('ymd') . strtoupper(bin2hex(random_bytes(4)));

    $stmt = mysqli_prepare(
        $conn,
        "UPDATE bookings
         SET status_pembayaran = 'lunas', dibayar_pada = ?
         WHERE kode_booking = ?"
    );
    mysqli_stmt_bind_param($stmt, 'ss', $sekarang, $kode);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    $stmt = mysqli_prepare(
        $conn,
        "INSERT INTO payments
         (kode_pembayaran, kode_booking, metode, jumlah, status, dibayar_pada)
         VALUES (?, ?, ?, ?, 'berhasil', ?)"
    );
    mysqli_stmt_bind_param($stmt, 'sssds', $kodeBayar, $kode, $metode, $total, $sekarang);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    mysqli_commit($conn);

    jsonOut(200, [
        'success' => true,
        'message' => 'Pembayaran berhasil.',
        'kode_pembayaran' => $kodeBayar,
        'metode' => $metode
    ]);
} catch (Throwable $e) {
    mysqli_rollback($conn);
    error_log('ComputerFix payment error: ' . $e->getMessage());
    jsonOut(500, ['success' => false, 'message' => 'Pembayaran gagal diproses.']);
}
