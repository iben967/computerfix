<?php
// GET ?kode=CF-xxxx  -> detail tagihan untuk halaman payment
require_once __DIR__ . '/koneksi.php';
require_once __DIR__ . '/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    jsonOut(405, ['success' => false, 'message' => 'Metode tidak diizinkan.']);
}

$kode = trim((string)($_GET['kode'] ?? ''));
if (!kodeValid($kode)) {
    jsonOut(400, ['success' => false, 'message' => 'Kode booking tidak valid.']);
}

bersihkanKadaluarsa($conn);

$stmt = mysqli_prepare(
    $conn,
    "SELECT kode_booking, nama, tanggal, TIME_FORMAT(jam, '%H:%i') AS jam,
            subtotal, biaya_booking, total, status_pembayaran, batas_bayar
     FROM bookings WHERE kode_booking = ?"
);
mysqli_stmt_bind_param($stmt, 's', $kode);
mysqli_stmt_execute($stmt);
$booking = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
mysqli_stmt_close($stmt);

if (!$booking) {
    jsonOut(404, [
        'success' => false,
        'message' => 'Tagihan tidak ditemukan atau sudah kedaluwarsa.'
    ]);
}

$items = [];
$stmt = mysqli_prepare(
    $conn,
    'SELECT nama_sparepart AS nama, kategori, harga, jumlah
     FROM booking_items WHERE kode_booking = ?'
);
mysqli_stmt_bind_param($stmt, 's', $kode);
mysqli_stmt_execute($stmt);
$res = mysqli_stmt_get_result($stmt);
while ($row = mysqli_fetch_assoc($res)) {
    $items[] = $row;
}
mysqli_stmt_close($stmt);

$sisaDetik = max(0, strtotime((string)$booking['batas_bayar']) - time());

jsonOut(200, [
    'success'      => true,
    'booking'      => $booking,
    'items'        => $items,
    'sisa_detik'   => $sisaDetik,
    'merchant'     => NAMA_MERCHANT,
    'nmid'         => NMID
]);
