<?php
// Pengaturan pembayaran ComputerFix
const BIAYA_BOOKING = 10000;   // biaya booking tetap (Rp). Isi 0 untuk menghapus.
const MENIT_BAYAR   = 15;      // batas waktu pembayaran (menit)
const NAMA_MERCHANT = 'COMPUTERFIX SURABAYA';
const NMID          = 'ID1026400000001'; // NMID contoh (simulasi)

date_default_timezone_set('Asia/Jakarta');

/**
 * Hapus booking yang belum dibayar dan sudah lewat batas waktu,
 * sehingga slot jadwalnya bisa dipakai orang lain lagi.
 */
function bersihkanKadaluarsa(mysqli $conn): void
{
    $sekarang = date('Y-m-d H:i:s');
    $stmt = mysqli_prepare(
        $conn,
        "DELETE FROM bookings
         WHERE status_pembayaran = 'menunggu' AND batas_bayar < ?"
    );
    mysqli_stmt_bind_param($stmt, 's', $sekarang);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
}

function jsonOut(int $status, array $data): void
{
    header('Content-Type: application/json; charset=utf-8');
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function kodeValid(string $kode): bool
{
    return (bool)preg_match('/^[A-Za-z0-9-]{3,20}$/', $kode);
}
