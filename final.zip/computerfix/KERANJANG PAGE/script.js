const cartItems = document.getElementById("cartItems");
const emptyCart = document.getElementById("emptyCart");
const bookingButton = document.getElementById("bookingButton");
const toast = document.getElementById("toast");
let toastTimer;

function rupiah(value) {
    return new Intl.NumberFormat("id-ID", {
        style:"currency", currency:"IDR", maximumFractionDigits:0
    }).format(value);
}

function getCart() {
    try {
        return JSON.parse(sessionStorage.getItem("computerfix_cart")) || [];
    } catch (error) {
        return [];
    }
}

function saveCart(cart) {
    sessionStorage.setItem("computerfix_cart", JSON.stringify(cart));
}

function showToast(message) {
    toast.textContent = message;
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("show"), 2300);
}

function renderCart() {
    const cart = getCart();
    const quantity = cart.reduce((sum, item) => sum + Number(item.jumlah || 0), 0);
    const subtotal = cart.reduce((sum, item) =>
        sum + Number(item.harga || 0) * Number(item.jumlah || 0), 0);

    document.getElementById("cartCount").textContent = quantity;
    document.getElementById("itemCount").textContent = quantity + " barang";
    document.getElementById("summaryQuantity").textContent = quantity + " unit";
    document.getElementById("summarySubtotal").textContent = rupiah(subtotal);
    document.getElementById("summaryTotal").textContent = rupiah(subtotal);

    emptyCart.hidden = cart.length !== 0;
    bookingButton.textContent = cart.length === 0
        ? "Booking Tanpa Sparepart →"
        : "Booking Sekarang →";
    cartItems.innerHTML = cart.map(item => `
        <article class="cart-item">
            <div class="item-image"><span>Gambar produk</span></div>
            <div class="item-details">
                <span class="item-category">${item.kategori || "Sparepart"}</span>
                <h3>${escapeHTML(item.nama)}</h3>
                <p class="item-price">${rupiah(item.harga)}</p>
                <div class="item-actions">
                    <div class="quantity-control">
                        <button data-action="minus" data-id="${item.id}" aria-label="Kurangi jumlah">−</button>
                        <span>${item.jumlah}</span>
                        <button data-action="plus" data-id="${item.id}" aria-label="Tambah jumlah">+</button>
                    </div>
                    <button class="remove-button" data-action="remove" data-id="${item.id}">Hapus</button>
                </div>
            </div>
            <strong class="item-total">${rupiah(item.harga * item.jumlah)}</strong>
        </article>
    `).join("");
}

function escapeHTML(value) {
    return String(value).replace(/[&<>"']/g, char => ({
        "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;"
    })[char]);
}

cartItems.addEventListener("click", event => {
    const button = event.target.closest("button[data-action]");
    if (!button) return;

    const cart = getCart();
    const item = cart.find(product => product.id === button.dataset.id);
    if (!item) return;

    if (button.dataset.action === "plus") {
        if (item.jumlah >= Number(item.stok || 99)) {
            showToast("Jumlah sudah mencapai stok demo.");
            return;
        }
        item.jumlah += 1;
    } else if (button.dataset.action === "minus") {
        item.jumlah -= 1;
        if (item.jumlah <= 0) {
            saveCart(cart.filter(product => product.id !== item.id));
            renderCart();
            return;
        }
    } else if (button.dataset.action === "remove") {
        saveCart(cart.filter(product => product.id !== item.id));
        showToast("Barang dihapus dari keranjang.");
        renderCart();
        return;
    }

    saveCart(cart);
    renderCart();
});

bookingButton.addEventListener("click", () => {
    window.location.href = "../BOOKING%20PAGE/index.html";
});

renderCart();
