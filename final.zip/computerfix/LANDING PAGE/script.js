/* =========================================
   COMPUTERFIX - JAVASCRIPT
   Keranjang dan Slider Gambar About
========================================= */


/* ==================== KERANJANG ==================== */

function initCartBadge() {
    const badge = document.getElementById("heroCartCount");
    const link = document.getElementById("heroCartLink");

    if (!badge || !link) return;

    let total = 0;

    try {
        const cart = JSON.parse(
            sessionStorage.getItem("computerfix_cart")
        );

        if (Array.isArray(cart)) {
            total = cart.reduce(function (sum, item) {
                return sum + (Number(item && item.jumlah) || 0);
            }, 0);
        }
    } catch (error) {
        total = 0;
    }

    if (total > 0) {
        badge.textContent = total;
        badge.hidden = false;

        link.setAttribute(
            "aria-label",
            "Keranjang, " + total + " barang"
        );
    } else {
        badge.textContent = "0";
        badge.hidden = true;
        link.setAttribute("aria-label", "Keranjang");
    }
}


/* ==================== SLIDER ABOUT ==================== */

function initAboutSlider() {
    const slider = document.getElementById("aboutSlider");

    if (!slider) return;

    const slides = slider.querySelectorAll(".about-slide");
    const dots = slider.querySelectorAll(".about-dot");

    const prev = document.getElementById("aboutPrev");
    const next = document.getElementById("aboutNext");

    if (slides.length === 0) return;

    let current = 0;
    let startX = 0;

    /* Menampilkan gambar yang dipilih */
    function showSlide(index) {
        current = (index + slides.length) % slides.length;

        slides.forEach(function (slide, i) {
            slide.classList.toggle("active", i === current);
        });

        dots.forEach(function (dot, i) {
            dot.classList.toggle("active", i === current);
        });
    }

    /* Tombol gambar sebelumnya */
    if (prev) {
        prev.addEventListener("click", function () {
            showSlide(current - 1);
        });
    }

    /* Tombol gambar berikutnya */
    if (next) {
        next.addEventListener("click", function () {
            showSlide(current + 1);
        });
    }

    /* Tombol titik indikator */
    dots.forEach(function (dot, i) {
        dot.addEventListener("click", function () {
            showSlide(i);
        });
    });

    /* Geser gambar di HP */
    slider.addEventListener(
        "touchstart",
        function (event) {
            if (event.touches.length > 0) {
                startX = event.touches[0].clientX;
            }
        },
        { passive: true }
    );

    slider.addEventListener(
        "touchend",
        function (event) {
            if (event.changedTouches.length === 0) return;

            const endX = event.changedTouches[0].clientX;
            const distance = endX - startX;

            if (Math.abs(distance) > 40) {
                if (distance < 0) {
                    showSlide(current + 1);
                } else {
                    showSlide(current - 1);
                }
            }
        },
        { passive: true }
    );

    /* Mulai dari gambar pertama */
    showSlide(0);
}


/* ==================== JALANKAN PROGRAM ==================== */

/* ==================== NOTIFIKASI SETELAH PEMBAYARAN ==================== */

function initFlash() {
    const box = document.getElementById("flashToast");
    if (!box) return;

    let message = null;
    try {
        message = sessionStorage.getItem("computerfix_flash");
        sessionStorage.removeItem("computerfix_flash");
    } catch (error) {
        message = null;
    }

    if (!message) return;

    box.textContent = "✓ " + message;
    box.hidden = false;

    setTimeout(function () {
        box.hidden = true;
    }, 6000);
}


function initComputerFix() {
    initFlash();
    initCartBadge();
    initAboutSlider();
}

if (document.readyState === "loading") {
    document.addEventListener(
        "DOMContentLoaded",
        initComputerFix
    );
} else {
    initComputerFix();
}